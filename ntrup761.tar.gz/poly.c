
#include <stdint.h>
#include <string.h>
#include "params.h"
#include "poly.h"
#define MODQ(x)((x)%NTRUP_Q)
#define CMODQ(x)((((x)>(NTRUP_Q>>1))?((x)-NTRUP_Q):((x)<-(NTRUP_Q>>1))?((x)+NTRUP_Q):(x)))


void poly_Rq_mul_small(int16_t *h, const int16_t *f,const int8_t *g)
{
    int32_t fg[NTRUP_P + NTRUP_P - 1];
    int i,j;
    memset(fg,0,sizeof(fg));


    for (i = 0; i < NTRUP_P; i++) {
            for(j=0;j<NTRUP_P;j++){
		fg[i+j]+=f[i]*g[j];
      }
    }

    for(i = NTRUP_P; i<2*NTRUP_P-1; i++){
        fg[i]=CMODQ(fg[i]);
        }


    for (i = 2 * NTRUP_P - 2; i>= NTRUP_P; i--) {
      fg[i - NTRUP_P] = CMODQ(fg[i - NTRUP_P] + fg[i]);
      fg[i - NTRUP_P + 1] = CMODQ(fg[i - NTRUP_P + 1] + fg[i]);
    }

    for (i = 0; i< NTRUP_P; i++){
        h[i] = fg[i];
    }
}
























