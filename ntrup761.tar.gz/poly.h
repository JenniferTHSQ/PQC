#ifndef POLYMUL_H
#define POLYMUL_H

#include <stdint.h>

void poly_Rq_mul_small(int16_t *h, const int16_t *f, const int8_t *g);


#endif



