#ifndef PARAMS_H
#define PARAMS_H

#define NTRUP_P 761
#define NTRUP_Q 4591

#endif




